import numpy as np #para manipular matrices usamos la bibloteca numpy y para ello instalamos (pip install numpy)

def encontrar_inversa(matriz):
    try:
        inversa = np.linalg.inv(matriz)
        return inversa
    except np.linalg.LinAlgError:#si la matris no se puede invertir arroja un error para eso agregamos el return siguiente
        return "La matriz no es invertible"

  # Ejemplo de uso
matriz_ejemplo = np.array([[4, 7], [2, 6]])
resultado = encontrar_inversa(matriz_ejemplo)
print("Inversa de la matriz:")
print(resultado)

#multiplicacion de matrices, MULTIPLICACION DE MATRICES, multiplicacion de matrices 

import numpy as np # nuevamente hacemos uso de la bliblioteca numpy

def multiplicar_matrices(matriz1, matriz2):
    try:
        resultado = np.dot(matriz1, matriz2)
        return resultado
    except ValueError:
        return "No se pueden multiplicar las matrices"

# nuwatra matriz de Ejemplo de uso
matriz_a = np.array([[2, -1], [1, 3]])
matriz_b = np.array([[5, 10], [7, 8]])

resultado_multiplicacion = multiplicar_matrices(matriz_a, matriz_b)
print("Resultado de la multiplicación de matrices:")
print(resultado_multiplicacion)


#resolver sistema de ecuaciones lineales 2x2 y 3x3 con regla de Cramer o gaus-jordan


import numpy as np
import matplotlib.pyplot as plt

def resolver_sistema(coeficientes, constantes):
    print("Elige un método para resolver el sistema:")
    print("1. Regla de Cramer")
    print("2. Gauss-Jordán")

    metodo_elegido = input("Ingresa el número del método: ")

    if metodo_elegido == '1':
        return resolver_cramer(coeficientes, constantes)
    elif metodo_elegido == '2':
        return resolver_gauss_jordan(coeficientes.astype(float), constantes.astype(float))
    else:
        return "Opción no válida. Elige 1 o 2."

def resolver_cramer(coeficientes, constantes):
    n = len(coeficientes)

    if n == 2:
        return resolver_cramer_2x2(coeficientes, constantes)
    elif n == 3:
        return resolver_cramer_3x3(coeficientes, constantes)
    else:
        return f"Regla de Cramer no implementada para sistemas de {n}x{n}."

def resolver_cramer_2x2(coeficientes, constantes):
    sistema_matriz = np.column_stack((coeficientes, constantes))
    determinante_principal = np.linalg.det(coeficientes)

    if determinante_principal == 0:
        return "El sistema no tiene solución única (determinante principal igual a cero)"

    soluciones = []
    for i in range(2):
        matriz_sustituida = sistema_matriz.copy()
        matriz_sustituida[:, i] = constantes
        determinante_sustituido = np.linalg.det(matriz_sustituida[:, :2])
        solucion = determinante_sustituido / determinante_principal
        soluciones.append(solucion)

    return soluciones

def resolver_cramer_3x3(coeficientes, constantes):
    sistema_matriz = np.column_stack((coeficientes, constantes))
    determinante_principal = np.linalg.det(coeficientes)

    if determinante_principal == 0:
        return "El sistema no tiene solución única (determinante principal igual a cero)"

    soluciones = []
    for i in range(3):
        matriz_sustituida = sistema_matriz.copy()
        matriz_sustituida[:, i] = constantes
        determinante_sustituido = np.linalg.det(matriz_sustituida[:, :3])
        solucion = determinante_sustituido / determinante_principal
        soluciones.append(solucion)

    return soluciones

def resolver_gauss_jordan(coeficientes, constantes):
    # Implementación básica de Gauss-Jordán
    n = len(coeficientes)
    sistema_matriz = np.column_stack((coeficientes, constantes)).astype(float)

    for i in range(n):
        # Pivote
        pivot = sistema_matriz[i, i]
        
        # Normalizar la fila actual
        sistema_matriz[i, :] /= pivot

        # Eliminar otras filas
        for j in range(n):
            if j != i:
                factor = sistema_matriz[j, i]
                sistema_matriz[j, :] -= factor * sistema_matriz[i, :]

    soluciones = sistema_matriz[:, -1]

    return soluciones

# Ejemplo de uso
coeficientes_ejemplo = np.array([[2, -1], [1, 3]])
constantes_ejemplo = np.array([5, 10])

soluciones = resolver_sistema(coeficientes_ejemplo, constantes_ejemplo)
print("Soluciones del sistema:")
print(soluciones)


#graficas de las ecuaciones a resolver

import numpy as np
import matplotlib.pyplot as plt

def resolver_cramer_graficos(coeficientes, constantes):
    n = len(coeficientes)

    if coeficientes.shape[0] != n or coeficientes.shape[1] != n:
        return f"La matriz de coeficientes no es {n}x{n} (regla de Cramer no aplicable)"

    sistema_matriz = np.column_stack((coeficientes, constantes))
    determinante_principal = np.linalg.det(coeficientes)

    if determinante_principal == 0:
        return "El sistema no tiene solución única (determinante principal igual a cero)"

    soluciones = []
    for i in range(n):
        matriz_sustituida = sistema_matriz.copy()
        matriz_sustituida[:, i] = constantes
        determinante_sustituido = np.linalg.det(matriz_sustituida[:, :n])
        solucion = determinante_sustituido / determinante_principal
        soluciones.append(solucion)

    # Graficar las ecuaciones
    plt.figure()

    for i in range(n):
        coeficientes_ecuacion = coeficientes[i]
        constante_ecuacion = constantes[i]

        if coeficientes_ecuacion[1] != 0:  # Evitar división por cero
            pendiente = -coeficientes_ecuacion[0] / coeficientes_ecuacion[1]
            intercepto = constante_ecuacion / coeficientes_ecuacion[1]

            x_vals = np.linspace(-10, 10, 100)
            y_vals = pendiente * x_vals + intercepto

            plt.plot(x_vals, y_vals, label=f'Ecuación {i + 1}')

    plt.xlabel('x')
    plt.ylabel('y')
    plt.legend()
    plt.grid(True)
    plt.title('Gráficos de las Ecuaciones Lineales')
    plt.show()

    return soluciones

# Ejemplo de uso
coeficientes_ejemplo_2x2 = np.array([[2, -1], [1, 3]])
constantes_ejemplo_2x2 = np.array([5, 10])

soluciones_2x2 = resolver_cramer_graficos(coeficientes_ejemplo_2x2, constantes_ejemplo_2x2)
print("Soluciones del sistema 2x2:")
print(soluciones_2x2)
